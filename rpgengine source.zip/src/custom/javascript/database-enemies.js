Object.assign(setup.enemyData,{
  "Example": {
    "bestiaryNo": false,
    "gender": 'N',
    "hp": 0,
    "stats": {

    },
    "tolerances": {

    },
    "elements": {

    },
    "cooldown": {

    },
    "actions": function () {
      while (V().action === null) {
        var act = random(1,100);

        if (true) {
          // action 1
        } else {
          // default action
        }

      } // end loop
      return;
    }
  },

});
