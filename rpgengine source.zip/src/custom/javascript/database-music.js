setup.musicData = {
	"Happy 8bit Loop 01": {
		author: "Tristan Lohengrin",
		license: "CC BY",
		distributor: "Freesound"
	}
};
