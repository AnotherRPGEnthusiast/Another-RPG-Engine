/*

Actor.prototype.addEffect = function (name,mods) {
  console.assert(typeof(name) == "string" || name instanceof Effect,`ERROR in addEffect: no effect passed`);
  mods = (mods || {});

  //  Define your own addEffect function here; it will overwrite the default
};

*/
