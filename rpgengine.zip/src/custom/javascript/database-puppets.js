Object.assign(setup.puppetData, {

  "Example": {
    "gender": 'N',
    "hp": 0,
    "stats": {

    },
    "actions": [

    ],
    "defaultAction": ''
  },
  
});
