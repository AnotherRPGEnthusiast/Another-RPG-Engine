Object.assign(setup.itemData, {

  "Example Item": {
    "usable": [],
    "value": 0,
    "onUse": function (puppet) {
      return;
    },
    "info": "",
    "desc": ""
  },
});
